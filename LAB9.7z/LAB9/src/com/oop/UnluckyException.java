package com.oop;

public class UnluckyException extends Exception{
}
